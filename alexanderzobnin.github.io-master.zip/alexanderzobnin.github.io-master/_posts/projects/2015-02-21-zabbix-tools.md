---
layout: project
title: Zabbix Tools
category: projects
tags: PowerShell Zabbix
---

##### Набор инструментов PowerShell для упрощения работы с системой мониторинга Zabbix в Windows.